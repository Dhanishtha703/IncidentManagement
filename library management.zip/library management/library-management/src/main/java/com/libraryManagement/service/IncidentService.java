package com.libraryManagement.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryManagement.model.Incident;
import com.libraryManagement.model.User;
import com.libraryManagement.repository.IncidentRepository;
import com.libraryManagement.repository.UserRepository;

@Service
public class IncidentService {
    @Autowired
    private IncidentRepository incidentRepository;

    

    public Incident createIncident(Incident incident, User reporter) {
        incident.setReporter(reporter);
        incident.setIncidentId(generateIncidentId());
        incident.setReportedDate(LocalDateTime.now());
        return incidentRepository.save(incident);
    }

    public List<Incident> getIncidentsForUser(User user) {
        return incidentRepository.findByReporter(user);
    }

    public Optional<Incident> findIncidentById(String incidentId) {
        return incidentRepository.findByIncidentId(incidentId);
    }

    private String generateIncidentId() {
        return "RMG" + (10000 + new Random().nextInt(90000)) + LocalDateTime.now().getYear();
    }
}

