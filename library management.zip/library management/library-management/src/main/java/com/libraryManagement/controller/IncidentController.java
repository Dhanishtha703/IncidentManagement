package com.libraryManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.libraryManagement.model.Incident;
import com.libraryManagement.model.User;
import com.libraryManagement.service.IncidentService;


@RestController
@RequestMapping("/api/incidents")
public class IncidentController {
    @Autowired
    private IncidentService incidentService;

    @PostMapping("/create")
    public ResponseEntity<?> createIncident(@RequestBody Incident incident, @AuthenticationPrincipal User user) {
        Incident newIncident = incidentService.createIncident(incident, user);
        return ResponseEntity.ok(newIncident);
    }

    @GetMapping("/my-incidents")
    public ResponseEntity<List<Incident>> getMyIncidents(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(incidentService.getIncidentsForUser(user));
    }

    @PutMapping("/edit/{incidentId}")
    public ResponseEntity<?> editIncident(@PathVariable String incidentId, @RequestBody Incident updatedIncident, @AuthenticationPrincipal User user) {
        Optional<Incident> existingIncident = incidentService.findIncidentById(incidentId);
        if (existingIncident.isPresent() && existingIncident.get().getReporter().equals(user)) {
            Incident incident = existingIncident.get();
            if (!incident.getStatus().equalsIgnoreCase("Closed")) {
                incident.setDetails(updatedIncident.getDetails());
                incident.setPriority(updatedIncident.getPriority());
                incident.setStatus(updatedIncident.getStatus());
                return ResponseEntity.ok(incidentService.createIncident(incident, user));
            } else {
                return ResponseEntity.badRequest().body("Cannot edit closed incident");
            }
        }
        return ResponseEntity.badRequest().body("Incident not found or unauthorized");
    }
}

