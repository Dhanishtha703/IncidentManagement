package com.libraryManagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.libraryManagement.model.Incident;
import com.libraryManagement.model.User;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long> {
    List<Incident> findByReporter(User reporter);
    
    //search by incident id
    Optional<Incident> findByIncidentId(String incidentId);
}

